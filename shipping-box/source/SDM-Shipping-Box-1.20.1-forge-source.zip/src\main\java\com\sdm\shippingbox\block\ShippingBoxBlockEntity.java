package com.sdm.shippingbox.block;

import com.sdm.shippingbox.Config;
import com.sdm.shippingbox.PriceRegistry;
import com.sdm.shippingbox.menu.ShippingBoxMenu;
import com.sdm.shippingbox.registry.ModBlockEntities;
import com.sdm.shippingbox.registry.ModItems;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.Container;
import net.minecraft.world.Containers;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;

public class ShippingBoxBlockEntity extends BlockEntity implements Container, net.minecraft.world.MenuProvider {

    public static final int INPUT_SLOTS = 9;
    public static final int PAYOUT_SLOT = 9;
    public static final int TOTAL_SLOTS = 10;

    private final ItemStackHandler items = new ItemStackHandler(TOTAL_SLOTS) {
        @Override
        protected void onContentsChanged(int slot) {
            ShippingBoxBlockEntity.this.setChanged();
        }

        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return ShippingBoxBlockEntity.this.mayAccept(slot, stack);
        }
    };

    private final LazyOptional<IItemHandler> itemHandler = LazyOptional.of(() -> this.items);

    private long pendingCoins;
    private int tickCounter;

    public ShippingBoxBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.SHIPPING_BOX.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, ShippingBoxBlockEntity box) {
        box.tickServer();
    }

    private void tickServer() {
        int interval = Math.max(1, Config.settleIntervalTicks());
        this.tickCounter++;
        if (this.tickCounter < interval) {
            return;
        }
        this.tickCounter = 0;
        this.settle();
    }

    public void settle() {
        long gained = 0L;
        boolean changed = false;
        for (int slot = 0; slot < INPUT_SLOTS; slot++) {
            ItemStack stack = this.items.getStackInSlot(slot);
            if (stack.isEmpty()) {
                continue;
            }
            int price = PriceRegistry.priceOf(stack);
            if (price <= 0) {
                continue;
            }
            gained += (long) price * (long) stack.getCount();
            this.items.setStackInSlot(slot, ItemStack.EMPTY);
            changed = true;
        }

        if (gained > 0L) {
            double multiplier = Config.saleMultiplier();
            long payout = multiplier == 1.0D ? gained : (long) Math.floor((double) gained * multiplier);
            if (payout > 0L) {
                this.pendingCoins += payout;
                changed = true;
            }
        }

        if (this.payoutCoins()) {
            changed = true;
        }

        if (changed) {
            this.setChanged();
        }
    }

    private boolean payoutCoins() {
        if (this.pendingCoins <= 0L) {
            return false;
        }
        ItemStack current = this.items.getStackInSlot(PAYOUT_SLOT);
        ItemStack coin = new ItemStack(ModItems.COIN.get());
        int limit = coin.getMaxStackSize();
        int space;
        if (current.isEmpty()) {
            space = limit;
        } else if (ItemStack.isSameItemSameTags(current, coin)) {
            space = limit - current.getCount();
        } else {
            space = 0;
        }
        if (space <= 0) {
            return false;
        }
        int amount = (int) Math.min(this.pendingCoins, (long) space);
        if (amount <= 0) {
            return false;
        }
        if (current.isEmpty()) {
            this.items.setStackInSlot(PAYOUT_SLOT, new ItemStack(ModItems.COIN.get(), amount));
        } else {
            ItemStack grown = current.copy();
            grown.grow(amount);
            this.items.setStackInSlot(PAYOUT_SLOT, grown);
        }
        this.pendingCoins -= amount;
        return true;
    }

    public void dropAllContents() {
        if (this.level == null) {
            return;
        }
        for (int slot = 0; slot < TOTAL_SLOTS; slot++) {
            ItemStack stack = this.items.getStackInSlot(slot);
            if (!stack.isEmpty()) {
                Containers.dropItemStack(this.level, this.worldPosition.getX() + 0.5D,
                        this.worldPosition.getY() + 0.5D, this.worldPosition.getZ() + 0.5D, stack);
                this.items.setStackInSlot(slot, ItemStack.EMPTY);
            }
        }
        this.setChanged();
    }

    private boolean mayAccept(int slot, ItemStack stack) {
        if (slot < 0 || slot >= INPUT_SLOTS || stack.isEmpty()) {
            return false;
        }
        return !Config.restrictInput() || PriceRegistry.hasPrice(stack);
    }

    public IItemHandler getItemHandler() {
        return this.items;
    }

    @Override
    public <T> LazyOptional<T> getCapability(Capability<T> capability, @Nullable Direction side) {
        if (capability == ForgeCapabilities.ITEM_HANDLER) {
            return this.itemHandler.cast();
        }
        return super.getCapability(capability, side);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        this.itemHandler.invalidate();
    }

    @Override
    public void reviveCaps() {
        super.reviveCaps();
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("Items", this.items.serializeNBT());
        tag.putLong("PendingCoins", this.pendingCoins);
        tag.putInt("Timer", this.tickCounter);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        if (tag.contains("Items")) {
            this.items.deserializeNBT(tag.getCompound("Items"));
        }
        this.pendingCoins = tag.getLong("PendingCoins");
        this.tickCounter = tag.getInt("Timer");
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = new CompoundTag();
        this.saveAdditional(tag);
        return tag;
    }

    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.sdmbox.shipping_box");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
        return new ShippingBoxMenu(id, inventory, this);
    }

    @Override
    public int getContainerSize() {
        return TOTAL_SLOTS;
    }

    @Override
    public boolean isEmpty() {
        for (int slot = 0; slot < TOTAL_SLOTS; slot++) {
            if (!this.items.getStackInSlot(slot).isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return this.items.getStackInSlot(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack extracted = this.items.extractItem(slot, amount, false);
        return extracted;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        ItemStack stack = this.items.getStackInSlot(slot);
        this.items.setStackInSlot(slot, ItemStack.EMPTY);
        return stack;
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        this.items.setStackInSlot(slot, stack);
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        for (int slot = 0; slot < TOTAL_SLOTS; slot++) {
            this.items.setStackInSlot(slot, ItemStack.EMPTY);
        }
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return this.mayAccept(slot, stack);
    }
}
