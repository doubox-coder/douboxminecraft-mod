# SDM Shipping Box

Forge 1.20.1 模组。方块名固定为英文 **Shipping Box**，中文名叫「出货箱」。

把能卖的东西丢进箱子，它按配置里的固定价格自动结算，并吐出自带货币 **SDM Coin**。

---

## 做什么

- 新增方块 **Shipping Box**（`sdmbox:shipping_box`），9 格输入区 + 1 格出款区
- 每 N 秒（默认 20 秒）扫一次输入区，凡是价格表里有的东西整组卖掉
- 卖价**只**来自配置文件，一个物品一条价格，与其它模组无关
- 结算后按总价生成 SDM Coin，堆在出款格，玩家自己取走
- 支持漏斗 / 管道自动输入（物品栏能力挂在方块实体上）
- 只能塞进价格表里有的物品（可关掉这个过滤）
- 破坏方块时箱内物品和未结清的钱一起掉落

## 合成

```
木板 木板 木板
木板 木桶 木板
木板 木板 木板
```

8 个任意木板 + 1 个木桶 = 1 个 Shipping Box。首次拿到木桶会在配方书里解锁。

## 价格配置

路径：`config/sdmbox-common.toml`

```toml
[economy]
    # 每隔多少秒结算一次
    settle_interval_seconds = 20
    # 全局倍率，1.0 = 按表付钱，0.9 = 抽一成税
    sale_multiplier = 1.0
    # true = 只收价格表里有的物品
    restrict_input = true
    drop_contents_on_break = true

[prices]
    entries = [
        "minecraft:wheat=3",
        "farmersdelight:tomato=3",
        "#forge:crops=2"
    ]
```

- 格式：`物品ID=价格`，价格单位是「枚硬币」，整数，必须大于 0
- 标签写法：`#标签ID=价格`，该标签下所有物品按这个价卖
- 同一个物品既有个体价格又在标签里，**个体价格优先**
- 写错的、模组没装的、ID 不存在的条目会被跳过并在日志里提示，不会报错崩溃

### 森罗物语系列怎么加

这块我没有预置，原因很实在：森罗物语的物品 ID 必须和你装的版本一致，凭印象编 ID 只会得到一堆无效条目。所以留的是明确入口，两种做法：

1. 游戏里按 `F3 + H` 打开高级提示框，把鼠标放在物品上看它的 ID，然后照格式加一行：
   ```toml
   "senluo:xxx=4"
   ```
2. 如果森罗物语的物品进了某个物品标签（例如 `#forge:crops`），可以直接加一条标签价，一次覆盖一大片。

农夫乐事部分已预置了一批常见物品（卷心菜、番茄、洋葱、米、培根、火腿等）。同理会跳过不存在的 ID。

改完配置后 `/reload` 或重启世界生效，价格表会重新读取。

## 货币

`sdmbox:coin`（SDM Coin / 出货币）。一枚硬币对应价目表里的 1 个价格单位。

注意：这版**没有**对接外部经济模组的余额，钱就是硬币物品本身。要换成别的付款形式（比如直接给绿宝石，或写进某个经济模组的账户），需要改 `ShippingBoxBlockEntity#payoutCoins` 这一段。

## 安装 / 构建

开发环境：

```bash
gradle build          # 产物在 build/libs/sdmbox-1.0.0.jar
```

需要 JDK 17（`gradle.properties` 里 `java.toolchain` 已锁 17），Forge 47.2.0，Gradle 会自己去拉 MDK 依赖。

装进游戏：把 jar 丢进 `mods/`，需要 Forge 1.20.1 47.x。

## 资源

- `tools/make_assets.py`：所有贴图、GUI 底图、模组图标都由这个手写像素脚本生成，可重复执行
- 方块贴图 16×16：`shipping_box_front / side / top / bottom`
- 硬币贴图 16×16：`item/coin.png`
- 容器底图 176×186：`gui/shipping_box.png`
- 模组图标 64×64：`logo.png`（木箱 + 硬币徽章）

## 还没验证的部分

- 这份源码**没有在本机编译过**：本机只有 Java 21，没有 Gradle 和 Forge 依赖仓库的联网条件，拉不到 MDK。所以第一次 `gradle build` 可能需要修一下依赖版本号。
- 没做玩家绑定：任何人对箱子右键都能打开，多人生存里别人也能取走你的硬币。要加锁的话是在 `ShippingBoxBlock#use` 里比对 UUID。
- GUI 里只画了格子，没画「卖出倒计时」之类的提示，结算节奏看配置。
