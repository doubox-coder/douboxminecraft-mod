package com.sdm.shippingbox.menu;

import com.sdm.shippingbox.block.ShippingBoxBlockEntity;
import com.sdm.shippingbox.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

public class ShippingBoxMenu extends AbstractContainerMenu {

    public static final int INPUT_SLOT_COUNT = 9;
    public static final int MENU_SLOT_COUNT = 10;

    private static final int INPUT_ORIGIN_X = 44;
    private static final int INPUT_ORIGIN_Y = 20;
    private static final int GRID_STEP = 18;
    private static final int PAYOUT_X = 128;
    private static final int PAYOUT_Y = 38;
    private static final int PLAYER_INV_Y = 104;
    private static final int HOTBAR_Y = 162;

    private final Container container;

    public ShippingBoxMenu(int id, Inventory inventory, FriendlyByteBuf data) {
        this(id, inventory, resolveClientContainer(inventory, data.readBlockPos()));
    }

    public ShippingBoxMenu(int id, Inventory inventory, Container container) {
        super(ModMenus.SHIPPING_BOX.get(), id);
        this.container = container;

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                int index = col + row * 3;
                this.addSlot(new Slot(container, index,
                        INPUT_ORIGIN_X + col * GRID_STEP,
                        INPUT_ORIGIN_Y + row * GRID_STEP) {
                    @Override
                    public boolean mayPlace(ItemStack stack) {
                        return container.canPlaceItem(this.getSlotIndex(), stack);
                    }
                });
            }
        }

        this.addSlot(new Slot(container, ShippingBoxBlockEntity.PAYOUT_SLOT, PAYOUT_X, PAYOUT_Y) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return false;
            }
        });

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(inventory, col + row * 9 + 9,
                        8 + col * GRID_STEP, PLAYER_INV_Y + row * GRID_STEP));
            }
        }

        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(inventory, col, 8 + col * GRID_STEP, HOTBAR_Y));
        }
    }

    private static Container resolveClientContainer(Inventory inventory, BlockPos pos) {
        BlockEntity blockEntity = inventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof ShippingBoxBlockEntity box) {
            return box;
        }
        return new SimpleContainer(ShippingBoxBlockEntity.TOTAL_SLOTS);
    }

    public Container getContainer() {
        return this.container;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        result = stack.copy();

        if (index < MENU_SLOT_COUNT) {
            if (!this.moveItemStackTo(stack, MENU_SLOT_COUNT, this.slots.size(), true)) {
                return ItemStack.EMPTY;
            }
        } else if (!this.moveItemStackTo(stack, 0, INPUT_SLOT_COUNT, false)) {
            return ItemStack.EMPTY;
        }

        if (stack.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        return result;
    }

    @Override
    public boolean stillValid(Player player) {
        return this.container.stillValid(player);
    }
}
