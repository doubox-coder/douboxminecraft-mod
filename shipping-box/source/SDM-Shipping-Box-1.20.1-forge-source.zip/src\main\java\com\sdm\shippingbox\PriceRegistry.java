package com.sdm.shippingbox;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

public final class PriceRegistry {

    private static final Map<Item, Integer> ITEM_PRICES = new HashMap<>();
    private static final List<TagPrice> TAG_PRICES = new ArrayList<>();

    private PriceRegistry() {
    }

    public static void bake() {
        ITEM_PRICES.clear();
        TAG_PRICES.clear();

        List<? extends String> entries;
        try {
            entries = Config.PRICES.get();
        } catch (IllegalStateException ex) {
            SDMShippingBox.LOGGER.warn("Price list requested before the config was loaded, using an empty list.");
            return;
        }

        for (String raw : entries) {
            if (raw == null) {
                continue;
            }
            String entry = raw.trim();
            if (entry.isEmpty()) {
                continue;
            }
            int split = entry.lastIndexOf('=');
            if (split <= 0 || split == entry.length() - 1) {
                SDMShippingBox.LOGGER.warn("Skipped malformed price entry: {}", entry);
                continue;
            }
            String key = entry.substring(0, split).trim();
            int price;
            try {
                price = Integer.parseInt(entry.substring(split + 1).trim());
            } catch (NumberFormatException ex) {
                SDMShippingBox.LOGGER.warn("Skipped price entry with a non-numeric price: {}", entry);
                continue;
            }
            if (price <= 0) {
                SDMShippingBox.LOGGER.warn("Skipped price entry with a price of zero or below: {}", entry);
                continue;
            }

            if (key.startsWith("#")) {
                ResourceLocation tagId = ResourceLocation.tryParse(key.substring(1).toLowerCase(Locale.ROOT));
                if (tagId == null) {
                    SDMShippingBox.LOGGER.warn("Skipped price entry with an invalid tag id: {}", entry);
                    continue;
                }
                TAG_PRICES.add(new TagPrice(TagKey.create(Registries.ITEM, tagId), price));
            } else {
                ResourceLocation itemId = ResourceLocation.tryParse(key.toLowerCase(Locale.ROOT));
                if (itemId == null) {
                    SDMShippingBox.LOGGER.warn("Skipped price entry with an invalid item id: {}", entry);
                    continue;
                }
                Item item = ForgeRegistries.ITEMS.getValue(itemId);
                if (item == null) {
                    SDMShippingBox.LOGGER.warn("No such item '{}', that price entry does nothing.", itemId);
                    continue;
                }
                ITEM_PRICES.put(item, price);
            }
        }

        SDMShippingBox.LOGGER.info("Loaded {} item prices and {} tag prices.", ITEM_PRICES.size(), TAG_PRICES.size());
    }

    public static int priceOf(ItemStack stack) {
        if (stack.isEmpty()) {
            return 0;
        }
        Integer direct = ITEM_PRICES.get(stack.getItem());
        if (direct != null) {
            return direct;
        }
        for (TagPrice tagPrice : TAG_PRICES) {
            if (stack.is(tagPrice.tag())) {
                return tagPrice.price();
            }
        }
        return 0;
    }

    public static boolean hasPrice(ItemStack stack) {
        return priceOf(stack) > 0;
    }

    private record TagPrice(TagKey<Item> tag, int price) {
    }
}
