package com.sdm.shippingbox;

import java.util.List;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.event.config.ModConfigEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public final class Config {

    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();

    private static final List<String> DEFAULT_PRICES = List.of(
            "minecraft:wheat=3",
            "minecraft:wheat_seeds=1",
            "minecraft:carrot=2",
            "minecraft:potato=2",
            "minecraft:baked_potato=3",
            "minecraft:beetroot=2",
            "minecraft:sugar_cane=2",
            "minecraft:sugar=3",
            "minecraft:egg=1",
            "minecraft:leather=2",
            "minecraft:feather=1",
            "minecraft:string=1",
            "minecraft:bone=1",
            "minecraft:bone_meal=1",
            "minecraft:gunpowder=4",
            "minecraft:slime_ball=2",
            "minecraft:rotten_flesh=1",
            "minecraft:spider_eye=2",
            "minecraft:coal=4",
            "minecraft:charcoal=3",
            "minecraft:raw_iron=6",
            "minecraft:iron_ingot=10",
            "minecraft:raw_copper=4",
            "minecraft:copper_ingot=6",
            "minecraft:raw_gold=10",
            "minecraft:gold_ingot=16",
            "minecraft:diamond=64",
            "minecraft:emerald=48",
            "minecraft:lapis_lazuli=6",
            "minecraft:redstone=3",
            "minecraft:quartz=4",
            "minecraft:amethyst_shard=8",
            "minecraft:netherite_scrap=64",
            "minecraft:oak_log=2",
            "minecraft:spruce_log=2",
            "minecraft:birch_log=2",
            "minecraft:jungle_log=2",
            "minecraft:acacia_log=2",
            "minecraft:dark_oak_log=2",
            "minecraft:mangrove_log=2",
            "minecraft:cherry_log=2",
            "minecraft:stone=1",
            "minecraft:cobblestone=1",
            "minecraft:sand=1",
            "minecraft:gravel=1",
            "minecraft:clay_ball=1",
            "minecraft:flint=2",
            "minecraft:kelp=1",
            "minecraft:dried_kelp=2",
            "minecraft:apple=4",
            "minecraft:honey_bottle=6",
            "minecraft:honeycomb=6",
            "minecraft:white_wool=4",
            "minecraft:bread=3",
            "minecraft:porkchop=3",
            "minecraft:cooked_porkchop=6",
            "minecraft:beef=3",
            "minecraft:cooked_beef=5",
            "minecraft:chicken=2",
            "minecraft:cooked_chicken=4",
            "minecraft:cod=2",
            "minecraft:cooked_cod=4",
            "minecraft:salmon=3",
            "minecraft:cooked_salmon=5",
            "minecraft:mutton=3",
            "minecraft:cooked_mutton=5",
            "minecraft:rabbit=2",
            "minecraft:cooked_rabbit=4",
            "farmersdelight:cabbage=3",
            "farmersdelight:cabbage_leaf=1",
            "farmersdelight:tomato=3",
            "farmersdelight:onion=3",
            "farmersdelight:rice=2",
            "farmersdelight:rice_panicle=2",
            "farmersdelight:bacon=5",
            "farmersdelight:cooked_bacon=7",
            "farmersdelight:ham=8",
            "farmersdelight:smoked_ham=12",
            "farmersdelight:wheat_dough=2",
            "farmersdelight:milk_bottle=2",
            "farmersdelight:fried_egg=3",
            "#forge:crops=2",
            "#forge:seeds=1"
    );

    public static final ForgeConfigSpec.IntValue SETTLE_INTERVAL_SECONDS;
    public static final ForgeConfigSpec.DoubleValue SALE_MULTIPLIER;
    public static final ForgeConfigSpec.BooleanValue RESTRICT_INPUT;
    public static final ForgeConfigSpec.BooleanValue DROP_CONTENTS_ON_BREAK;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> PRICES;

    public static final ForgeConfigSpec SPEC;

    static {
        BUILDER.comment(
                "SDM Shipping Box - all prices live in this file.",
                "Prices are counted in SDM Coins. One sold item gives exactly the number written here.",
                "Every price change is applied after a resource reload / world restart."
        ).push("economy");

        SETTLE_INTERVAL_SECONDS = BUILDER
                .comment("How often (in seconds) the box scans its input area and sells everything sellable.")
                .defineInRange("settle_interval_seconds", 20, 1, 3600);

        SALE_MULTIPLIER = BUILDER
                .comment("Global payout multiplier, applied to the total of one settlement and rounded down.",
                        "1.0 = prices as written, 0.9 = a 10 percent tax, 2.0 = double money events.")
                .defineInRange("sale_multiplier", 1.0D, 0.0D, 100.0D);

        RESTRICT_INPUT = BUILDER
                .comment("true = the box only accepts items that have a price in this file (a built-in filter).",
                        "false = any item can be dropped in, unpriced items simply stay inside and are never sold.")
                .define("restrict_input", true);

        DROP_CONTENTS_ON_BREAK = BUILDER
                .comment("true = breaking the box drops everything inside, including the coins still waiting for payout.")
                .define("drop_contents_on_break", true);

        BUILDER.pop();

        BUILDER.comment(
                "",
                "---------------- PRICE LIST ----------------",
                "Format:  item_id=price       or       #tag_id=price",
                "Example: farmersdelight:tomato=3",
                "Example: #forge:crops=2     (anything inside that item tag sells for 2)",
                "The item_id form always wins over a tag. Unknown ids are skipped silently, so a price list",
                "for a mod you have not installed does no harm.",
                "",
                "For Senluo Monogatari (Senraku / 森罗物语) items: add one line per item using the real id,",
                "e.g.  senluo:xxx=4  -- check the id with F3+H advanced tooltips or /give suggestions.",
                "Nothing is pre-filled for that series here, because ids must match the installed build.",
                "-------------------------------------------"
        ).push("prices");

        PRICES = BUILDER
                .comment("One entry per line.")
                .defineList("entries", DEFAULT_PRICES, Config::isValidPriceEntry);

        BUILDER.pop();

        SPEC = BUILDER.build();
    }

    private Config() {
    }

    private static boolean isValidPriceEntry(Object value) {
        if (!(value instanceof String entry)) {
            return false;
        }
        int split = entry.lastIndexOf('=');
        if (split <= 1 || split == entry.length() - 1) {
            return false;
        }
        try {
            Integer.parseInt(entry.substring(split + 1).trim());
            return true;
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    public static int settleIntervalTicks() {
        return SETTLE_INTERVAL_SECONDS.get() * 20;
    }

    public static double saleMultiplier() {
        return SALE_MULTIPLIER.get();
    }

    public static boolean restrictInput() {
        return RESTRICT_INPUT.get();
    }

    public static boolean dropContentsOnBreak() {
        return DROP_CONTENTS_ON_BREAK.get();
    }

    @SubscribeEvent
    public static void onLoad(ModConfigEvent.Loading event) {
        if (event.getConfig().getSpec() == SPEC) {
            PriceRegistry.bake();
        }
    }

    @SubscribeEvent
    public static void onReload(ModConfigEvent.Reloading event) {
        if (event.getConfig().getSpec() == SPEC) {
            PriceRegistry.bake();
        }
    }
}
