package com.sdm.shippingbox.registry;

import com.sdm.shippingbox.SDMShippingBox;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SDMShippingBox.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModCapabilities {

    private ModCapabilities() {
    }

    @SubscribeEvent
    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(ForgeCapabilities.ITEM_HANDLER,
                ModBlockEntities.SHIPPING_BOX.get(),
                (box, side) -> box.getItemHandler());
    }
}
