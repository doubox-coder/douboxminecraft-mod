package com.sdm.shippingbox;

import java.util.List;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.event.config.ModConfigEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public final class Config {

    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();

    private static final List<String> DEFAULT_PRICES = List.of(
            "farmersdelight:tomato=3.10",
            "#forge:crops=2"
    );

    public static final ForgeConfigSpec.IntValue SETTLE_INTERVAL_SECONDS;
    public static final ForgeConfigSpec.DoubleValue SALE_MULTIPLIER;
    public static final ForgeConfigSpec.BooleanValue RESTRICT_INPUT;
    public static final ForgeConfigSpec.BooleanValue DROP_CONTENTS_ON_BREAK;
    public static final ForgeConfigSpec.BooleanValue BANK_ENABLED;
    public static final ForgeConfigSpec.BooleanValue USE_SDM_ECONOMY;
    public static final ForgeConfigSpec.ConfigValue<String> SDM_CURRENCY_KEY;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> PRICES;

    public static final ForgeConfigSpec SPEC;

    static {
        BUILDER.comment(
                "SDM Shipping Box - all prices live in this file.",
                "Prices are counted in SDM Coins. One sold item gives exactly the number written here.",
                "Every price change is applied after a resource reload / world restart."
        ).push("economy");

        SETTLE_INTERVAL_SECONDS = BUILDER
                .comment("How often (in seconds) the box scans its input area and sells everything sellable.")
                .defineInRange("settle_interval_seconds", 20, 1, 3600);

        SALE_MULTIPLIER = BUILDER
                .comment("Global payout multiplier, applied to the total of one settlement and rounded down.",
                        "1.0 = prices as written, 0.9 = a 10 percent tax, 2.0 = double money events.")
                .defineInRange("sale_multiplier", 1.0D, 0.0D, 100.0D);

        RESTRICT_INPUT = BUILDER
                .comment("true = the box only accepts items that have a price in this file (a built-in filter).",
                        "false = any item can be dropped in, unpriced items simply stay inside and are never sold.")
                .define("restrict_input", true);

        DROP_CONTENTS_ON_BREAK = BUILDER
                .comment("true = breaking the box drops everything inside. Money already earned is remembered",
                        "by the box and paid out the next time its owner is online.")
                .define("drop_contents_on_break", true);

        BANK_ENABLED = BUILDER
                .comment("Shift + right click the box while holding SDM Coins to bank them.",
                        "Selling no longer pays in coins, so this only matters for coins picked up elsewhere.",
                        "true = the bank keeps a per-player balance, checked with /sdmbank balance and taken out",
                        "with /sdmbank withdraw <amount>.")
                .define("bank_enabled", true);

        USE_SDM_ECONOMY = BUILDER
                .comment("true = banked coins are handed to SDM Economy (mod id sdm_economy) and become its money,",
                        "the same currency the SDM Shop spends. If that mod is not installed the box quietly",
                        "falls back to its own balance.")
                .define("use_sdm_economy", true);

        SDM_CURRENCY_KEY = BUILDER
                .comment("Currency key inside SDM Economy. CurrencyRegister.init() registers \"basic_money\",",
                        "which is what the shop uses. Change it only if you added another currency.")
                .define("sdm_currency_key", "basic_money");

        BUILDER.pop();

        BUILDER.comment(
                "",
                "---------------- PRICE LIST ----------------",
                "Format:  item_id=price       or       #tag_id=price",
                "Example: farmersdelight:tomato=3.10",
                "Example: #forge:crops=2.55   (anything inside that item tag sells for 2.55)",
                "Prices may use decimals (two places are kept). The bundled list gives every item its own price.",
                "The item_id form always wins over a tag. Unknown ids are skipped silently, so a price list",
                "for a mod you have not installed does no harm.",
                "",
                "For Senluo Monogatari (Senraku / 森罗物语) items: add one line per item using the real id,",
                "e.g.  senluo:xxx=4  -- check the id with F3+H advanced tooltips or /give suggestions.",
                "Nothing is pre-filled for that series here, because ids must match the installed build.",
                "-------------------------------------------"
        ).push("prices");

        PRICES = BUILDER
                .comment("One entry per line.")
                .defineList("entries", DEFAULT_PRICES, Config::isValidPriceEntry);

        BUILDER.pop();

        SPEC = BUILDER.build();
    }

    private Config() {
    }

    private static boolean isValidPriceEntry(Object value) {
        if (!(value instanceof String entry)) {
            return false;
        }
        int split = entry.lastIndexOf('=');
        if (split <= 1 || split == entry.length() - 1) {
            return false;
        }
        try {
            double price = Double.parseDouble(entry.substring(split + 1).trim());
            return Double.isFinite(price) && price > 0.0D;
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    public static int settleIntervalTicks() {
        return SETTLE_INTERVAL_SECONDS.get() * 20;
    }

    public static double saleMultiplier() {
        return SALE_MULTIPLIER.get();
    }

    public static boolean restrictInput() {
        return RESTRICT_INPUT.get();
    }

    public static boolean dropContentsOnBreak() {
        return DROP_CONTENTS_ON_BREAK.get();
    }

    public static boolean bankEnabled() {
        return BANK_ENABLED.get();
    }

    public static boolean useSdmEconomy() {
        return USE_SDM_ECONOMY.get();
    }

    public static String sdmCurrencyKey() {
        return SDM_CURRENCY_KEY.get();
    }

    @SubscribeEvent
    public static void onLoad(ModConfigEvent.Loading event) {
        if (event.getConfig().getSpec() == SPEC) {
            PriceRegistry.bake();
        }
    }

    @SubscribeEvent
    public static void onReload(ModConfigEvent.Reloading event) {
        if (event.getConfig().getSpec() == SPEC) {
            PriceRegistry.bake();
        }
    }
}
