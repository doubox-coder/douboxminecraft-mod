package com.sdm.shippingbox.registry;

import com.sdm.shippingbox.SDMShippingBox;
import com.sdm.shippingbox.menu.ShippingBoxMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModMenus {

    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, SDMShippingBox.MOD_ID);

    public static final RegistryObject<MenuType<ShippingBoxMenu>> SHIPPING_BOX =
            MENUS.register("shipping_box", () -> IForgeMenuType.create(ShippingBoxMenu::new));

    private ModMenus() {
    }
}
