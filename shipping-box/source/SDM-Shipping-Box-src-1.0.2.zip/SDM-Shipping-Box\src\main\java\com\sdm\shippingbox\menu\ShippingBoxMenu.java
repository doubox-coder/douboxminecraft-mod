package com.sdm.shippingbox.menu;

import com.sdm.shippingbox.block.ShippingBoxBlockEntity;
import com.sdm.shippingbox.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

public class ShippingBoxMenu extends AbstractContainerMenu {

    public static final int INPUT_SLOT_COUNT = ShippingBoxBlockEntity.INPUT_SLOTS;
    public static final int MENU_SLOT_COUNT = ShippingBoxBlockEntity.TOTAL_SLOTS;

    private static final int GRID_X = 8;
    private static final int GRID_Y = 18;
    private static final int STEP = 18;
    private static final int PLAYER_INV_Y = 140;
    private static final int HOTBAR_Y = 198;

    private final Container container;

    public ShippingBoxMenu(int id, Inventory inventory, FriendlyByteBuf data) {
        this(id, inventory, resolveClientContainer(inventory, data.readBlockPos()));
    }

    public ShippingBoxMenu(int id, Inventory inventory, Container container) {
        super(ModMenus.SHIPPING_BOX.get(), id);
        this.container = container;

        for (int row = 0; row < 6; row++) {
            for (int col = 0; col < 9; col++) {
                final int slotIndex = col + row * 9;
                this.addSlot(new Slot(container, slotIndex, GRID_X + col * STEP, GRID_Y + row * STEP) {
                    @Override
                    public boolean mayPlace(ItemStack stack) {
                        return container.canPlaceItem(slotIndex, stack);
                    }
                });
            }
        }

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(inventory, col + row * 9 + 9,
                        GRID_X + col * STEP, PLAYER_INV_Y + row * STEP));
            }
        }

        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(inventory, col, GRID_X + col * STEP, HOTBAR_Y));
        }
    }

    private static Container resolveClientContainer(Inventory inventory, BlockPos pos) {
        BlockEntity blockEntity = inventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof ShippingBoxBlockEntity box) {
            return box;
        }
        return new SimpleContainer(ShippingBoxBlockEntity.TOTAL_SLOTS);
    }

    public Container getContainer() {
        return this.container;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        result = stack.copy();

        if (index < MENU_SLOT_COUNT) {
            if (!this.moveItemStackTo(stack, MENU_SLOT_COUNT, this.slots.size(), true)) {
                return ItemStack.EMPTY;
            }
        } else if (!this.moveItemStackTo(stack, 0, INPUT_SLOT_COUNT, false)) {
            return ItemStack.EMPTY;
        }

        if (stack.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        return result;
    }

    @Override
    public boolean stillValid(Player player) {
        return this.container.stillValid(player);
    }
}
