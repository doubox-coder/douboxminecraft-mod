package com.sdm.shippingbox.registry;

import com.sdm.shippingbox.SDMShippingBox;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModTabs {

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SDMShippingBox.MOD_ID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.sdmbox"))
                    .icon(() -> new ItemStack(ModItems.SHIPPING_BOX.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.SHIPPING_BOX.get());
                        output.accept(ModItems.COIN.get());
                    })
                    .build());

    private ModTabs() {
    }
}
