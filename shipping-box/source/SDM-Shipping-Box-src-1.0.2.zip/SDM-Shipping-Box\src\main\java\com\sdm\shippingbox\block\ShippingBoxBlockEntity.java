package com.sdm.shippingbox.block;

import com.sdm.shippingbox.Config;
import com.sdm.shippingbox.PriceRegistry;
import com.sdm.shippingbox.bank.BankService;
import com.sdm.shippingbox.menu.ShippingBoxMenu;
import com.sdm.shippingbox.registry.ModBlockEntities;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;

/**
 * The shipping box sells everything sellable inside it and pays the owner straight into SDM money.
 * There is no coin item and no payout slot any more: the money goes to the player's purse.
 *
 * Sold amounts are also counted per game day, so the first morning after selling the owner gets a
 * big "yesterday you sold ..." banner on screen.
 */
public class ShippingBoxBlockEntity extends BlockEntity implements Container, MenuProvider {

    public static final int INPUT_SLOTS = 54;
    public static final int TOTAL_SLOTS = 54;

    private static final int TITLE_FADE_IN = 20;
    private static final int TITLE_STAY = 100;
    private static final int TITLE_FADE_OUT = 20;

    private final ItemStackHandler items = new ItemStackHandler(TOTAL_SLOTS) {
        @Override
        protected void onContentsChanged(int slot) {
            ShippingBoxBlockEntity.this.setChanged();
        }

        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return ShippingBoxBlockEntity.this.mayAccept(slot, stack);
        }
    };

    private final LazyOptional<IItemHandler> itemHandler = LazyOptional.of(() -> this.items);

    /** money earned but not handed over yet (owner offline, or no owner recorded) */
    private double pendingPayout;
    private int tickCounter;

    @Nullable
    private UUID owner;

    /** current game day, -1 until the first tick */
    private long currentDay = -1L;

    /** what was sold during the current day */
    private int dayCount;
    private double dayCoins;
    private final Map<String, Integer> dayItems = new HashMap<>();

    /** the finished day waiting to be shown to the owner */
    private int reportCount;
    private double reportCoins;
    private final Map<String, Integer> reportItems = new HashMap<>();
    private boolean reportWaiting;

    public ShippingBoxBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.SHIPPING_BOX.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, ShippingBoxBlockEntity box) {
        box.tickServer();
    }

    private void tickServer() {
        if (this.level == null) {
            return;
        }
        this.rollDayIfNeeded();
        this.flushPendingPayout();
        this.showReportIfPossible();

        int interval = Math.max(1, Config.settleIntervalTicks());
        this.tickCounter++;
        if (this.tickCounter < interval) {
            return;
        }
        this.tickCounter = 0;
        this.settle();
    }

    public void settle() {
        double gained = 0.0D;
        boolean changed = false;
        for (int slot = 0; slot < INPUT_SLOTS; slot++) {
            ItemStack stack = this.items.getStackInSlot(slot);
            if (stack.isEmpty()) {
                continue;
            }
            double price = PriceRegistry.priceOf(stack);
            if (price <= 0.0D) {
                continue;
            }
            int count = stack.getCount();
            gained += price * (double) count;
            this.countSold(stack, count);
            this.items.setStackInSlot(slot, ItemStack.EMPTY);
            changed = true;
        }

        if (gained > 0.0D) {
            double multiplier = Config.saleMultiplier();
            this.pendingPayout += gained * multiplier;
            this.flushPendingPayout();
            changed = true;
        }

        if (changed) {
            this.setChanged();
        }
    }

    private void countSold(ItemStack stack, int count) {
        this.dayCount += count;
        this.dayCoins += PriceRegistry.priceOf(stack) * (double) count * Config.saleMultiplier();
        String id = BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
        this.dayItems.merge(id, count, Integer::sum);
    }

    /** Hands the money to the owner, straight into SDM money. Stays pending while the owner is away. */
    private void flushPendingPayout() {
        if (this.pendingPayout <= 0.0D) {
            return;
        }
        ServerPlayer owner = this.ownerPlayer();
        if (owner == null) {
            return;
        }
        long coins = (long) Math.floor(this.pendingPayout + 1.0E-6D);
        if (coins <= 0L) {
            return;
        }
        long balance = BankService.credit(owner, coins);
        this.pendingPayout -= (double) coins;
        if (this.pendingPayout < 0.005D) {
            this.pendingPayout = 0.0D;
        }
        owner.displayClientMessage(balance >= 0L
                ? Component.translatable("message.sdmbox.sold", coins, balance)
                : Component.translatable("message.sdmbox.sold_nobalance", coins), true);
        this.setChanged();
    }

    private void rollDayIfNeeded() {
        long day = this.level.getDayTime() / 24000L;
        if (this.currentDay < 0L) {
            this.currentDay = day;
            return;
        }
        if (day == this.currentDay) {
            return;
        }
        this.currentDay = day;
        if (this.dayCount <= 0) {
            return;
        }
        this.reportCount = this.dayCount;
        this.reportCoins = this.dayCoins;
        this.reportItems.clear();
        this.reportItems.putAll(this.dayItems);
        this.reportWaiting = true;
        this.dayCount = 0;
        this.dayCoins = 0.0D;
        this.dayItems.clear();
        this.setChanged();
    }

    /** One big line on screen: what was sold yesterday and what it paid. */
    private void showReportIfPossible() {
        if (!this.reportWaiting || this.reportCount <= 0) {
            return;
        }
        ServerPlayer owner = this.ownerPlayer();
        if (owner == null) {
            return;
        }
        if (owner.isSleeping()) {
            // wait until the player climbs out of bed, otherwise the sleep screen hides the banner
            return;
        }
        this.reportWaiting = false;
        this.setChanged();

        owner.connection.send(new ClientboundSetTitlesAnimationPacket(TITLE_FADE_IN, TITLE_STAY, TITLE_FADE_OUT));
        owner.connection.send(new ClientboundSetSubtitleTextPacket(this.reportSubtitle()));
        owner.connection.send(new ClientboundSetTitleTextPacket(
                Component.translatable("title.sdmbox.yesterday", this.reportCount)));
    }

    private Component reportSubtitle() {
        MutableComponent line = Component.empty();
        int shown = 0;
        for (Map.Entry<String, Integer> entry : this.topReportItems(3)) {
            ResourceLocation id = ResourceLocation.tryParse(entry.getKey());
            Item item = id == null ? null : BuiltInRegistries.ITEM.get(id);
            Component name = item == null ? Component.literal(entry.getKey()) : item.getDescription();
            if (shown > 0) {
                line.append(Component.literal("  "));
            }
            line.append(name).append(Component.literal(" x" + entry.getValue()));
            shown++;
        }
        long coins = (long) Math.floor(this.reportCoins + 1.0E-6D);
        if (shown > 0) {
            line.append(Component.literal("  |  "));
        }
        return line.append(Component.translatable("subtitle.sdmbox.yesterday", coins));
    }

    private Iterable<Map.Entry<String, Integer>> topReportItems(int limit) {
        Map<String, Integer> sorted = new LinkedHashMap<>();
        this.reportItems.entrySet().stream()
                .sorted((a, b) -> Integer.compare(b.getValue(), a.getValue()))
                .limit(limit)
                .forEach(e -> sorted.put(e.getKey(), e.getValue()));
        return sorted.entrySet();
    }

    private ServerPlayer ownerPlayer() {
        if (this.owner == null || this.level == null || this.level.getServer() == null) {
            return null;
        }
        return this.level.getServer().getPlayerList().getPlayer(this.owner);
    }

    public void setOwner(Player player) {
        if (this.owner == null && player != null) {
            this.owner = player.getUUID();
            this.setChanged();
        }
    }

    public void dropAllContents() {
        if (this.level == null) {
            return;
        }
        for (int slot = 0; slot < TOTAL_SLOTS; slot++) {
            ItemStack stack = this.items.getStackInSlot(slot);
            if (!stack.isEmpty()) {
                Containers.dropItemStack(this.level, this.worldPosition.getX() + 0.5D,
                        this.worldPosition.getY() + 0.5D, this.worldPosition.getZ() + 0.5D, stack);
                this.items.setStackInSlot(slot, ItemStack.EMPTY);
            }
        }
        this.setChanged();
    }

    private boolean mayAccept(int slot, ItemStack stack) {
        if (slot < 0 || slot >= INPUT_SLOTS || stack.isEmpty()) {
            return false;
        }
        return !Config.restrictInput() || PriceRegistry.hasPrice(stack);
    }

    public IItemHandler getItemHandler() {
        return this.items;
    }

    @Override
    public <T> LazyOptional<T> getCapability(Capability<T> capability, @Nullable Direction side) {
        if (capability == ForgeCapabilities.ITEM_HANDLER) {
            return this.itemHandler.cast();
        }
        return super.getCapability(capability, side);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        this.itemHandler.invalidate();
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("Items", this.items.serializeNBT());
        tag.putDouble("PendingPayout", this.pendingPayout);
        tag.putInt("Timer", this.tickCounter);
        tag.putLong("Day", this.currentDay);
        if (this.owner != null) {
            tag.putUUID("Owner", this.owner);
        }
        tag.putInt("DayCount", this.dayCount);
        tag.putDouble("DayCoins", this.dayCoins);
        tag.put("DayItems", writeItems(this.dayItems));
        tag.putInt("ReportCount", this.reportCount);
        tag.putDouble("ReportCoins", this.reportCoins);
        tag.put("ReportItems", writeItems(this.reportItems));
        tag.putBoolean("ReportWaiting", this.reportWaiting);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        if (tag.contains("Items")) {
            this.items.deserializeNBT(tag.getCompound("Items"));
        }
        this.pendingPayout = tag.getDouble("PendingPayout");
        this.tickCounter = tag.getInt("Timer");
        this.currentDay = tag.contains("Day") ? tag.getLong("Day") : -1L;
        this.owner = tag.hasUUID("Owner") ? tag.getUUID("Owner") : null;
        this.dayCount = tag.getInt("DayCount");
        this.dayCoins = tag.getDouble("DayCoins");
        readItems(tag.getList("DayItems", Tag.TAG_COMPOUND), this.dayItems);
        this.reportCount = tag.getInt("ReportCount");
        this.reportCoins = tag.getDouble("ReportCoins");
        readItems(tag.getList("ReportItems", Tag.TAG_COMPOUND), this.reportItems);
        this.reportWaiting = tag.getBoolean("ReportWaiting");
    }

    private static ListTag writeItems(Map<String, Integer> source) {
        ListTag list = new ListTag();
        for (Map.Entry<String, Integer> entry : source.entrySet()) {
            CompoundTag line = new CompoundTag();
            line.putString("Id", entry.getKey());
            line.putInt("Count", entry.getValue());
            list.add(line);
        }
        return list;
    }

    private static void readItems(ListTag list, Map<String, Integer> target) {
        target.clear();
        for (int i = 0; i < list.size(); i++) {
            CompoundTag line = list.getCompound(i);
            String id = line.getString("Id");
            if (!id.isEmpty()) {
                target.put(id, line.getInt("Count"));
            }
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = new CompoundTag();
        this.saveAdditional(tag);
        return tag;
    }

    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.sdmbox.shipping_box");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
        this.setOwner(player);
        this.flushPendingPayout();
        this.showReportIfPossible();
        return new ShippingBoxMenu(id, inventory, this);
    }

    @Override
    public int getContainerSize() {
        return TOTAL_SLOTS;
    }

    @Override
    public boolean isEmpty() {
        for (int slot = 0; slot < TOTAL_SLOTS; slot++) {
            if (!this.items.getStackInSlot(slot).isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return this.items.getStackInSlot(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        return this.items.extractItem(slot, amount, false);
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        ItemStack stack = this.items.getStackInSlot(slot);
        this.items.setStackInSlot(slot, ItemStack.EMPTY);
        return stack;
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        this.items.setStackInSlot(slot, stack);
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        for (int slot = 0; slot < TOTAL_SLOTS; slot++) {
            this.items.setStackInSlot(slot, ItemStack.EMPTY);
        }
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return this.mayAccept(slot, stack);
    }
}
