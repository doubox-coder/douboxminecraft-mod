"""Builds a price list for SDM Shipping Box from real mod jars.

Item ids come from each jar's own assets/<modid>/models/item/*.json entries, so every id written
out really exists in that jar. Prices are a heuristic starting point, not a claim about game balance:
tweak config/sdmbox-common.toml for anything you care about.

Usage:
    python tools/gen_prices.py --mods "D:\\path\\mods" --out mod_prices.txt [--mc-jar client.jar]
"""

import argparse
import os
import re
import zipfile

FOOD = re.compile(
    r"(cooked|baked|roasted|grilled|fried|smoked|dried|soup|stew|pie|cake|cookie|bread|"
    r"rice|noodle|pasta|dumpling|bun|sushi|salad|sandwich|burger|cheese|jerky|sausage|"
    r"bacon|ham|meat|fish|fillet|egg|juice|tea|coffee|wine|sake|beer|honey|jam|syrup|"
    r"toast|pancake|waffle|curry|broth|porridge|chowder|gumbo|taco|pizza|muffin|donut|"
    r"cream|chocolate|fruit|berry|vegetable|mushroom|tomato|onion|cabbage|carrot|potato|"
    r"corn|wheat|seed|crop|herb|spice|pepper|salt|sugar|flour|dough|food|meal|dish|"
    r"pie|pudding|dessert|snack|candy|sweet|drink|bottle|dish)",
    re.IGNORECASE,
)

COOKED = re.compile(r"(cooked|baked|roasted|grilled|fried|smoked|pie|cake|stew|soup|curry|meal|dish)", re.IGNORECASE)
DRINK = re.compile(r"(juice|tea|coffee|wine|sake|beer|drink|bottle|cider)", re.IGNORECASE)
SWEET = re.compile(r"(cake|cookie|candy|sweet|chocolate|donut|muffin|pudding|dessert|jam|syrup|honey)", re.IGNORECASE)
RAW = re.compile(r"^(raw_|.*_seed|.*seeds$|.*_crop$|.*_sapling$)", re.IGNORECASE)

MATERIALS = [
    (re.compile(r"(netherite|ancient_debris|diamond)", re.IGNORECASE), 64),
    (re.compile(r"(emerald)", re.IGNORECASE), 48),
    (re.compile(r"(gold|rose_gold)", re.IGNORECASE), 16),
    (re.compile(r"(iron|steel)", re.IGNORECASE), 10),
    (re.compile(r"(copper|bronze|brass|silver|tin|lead|nickel|zinc)", re.IGNORECASE), 6),
    (re.compile(r"(coal|charcoal)", re.IGNORECASE), 4),
    (re.compile(r"(lapis|amethyst|quartz|redstone)", re.IGNORECASE), 6),
    (re.compile(r"(wood|log|plank|stone|cobble|sand|gravel|dirt|clay|flint|leather|wool|string|bone|feather)", re.IGNORECASE), 2),
    (re.compile(r"(ingot|nugget|gem|shard|dust|scrap|fragment|crystal|pearl|blaze|shell|membrane)", re.IGNORECASE), 5),
]

SKIP = re.compile(
    r"(spawn_egg|debug|creative|example|test|template|empty|dummy|placeholder|configurator|"
    r"wand|tooltip|guide|manual|book$|pamphlet|icon|logo)",
    re.IGNORECASE,
)


def price_of(item_id):
    name = item_id.split(":")[-1]
    if SKIP.search(name):
        return 0
    if FOOD.search(name):
        if DRINK.search(name):
            return 8
        if SWEET.search(name):
            return 7
        if COOKED.search(name):
            return 6
        if RAW.search(name):
            return 2
        return 3
    for pattern, price in MATERIALS:
        if pattern.search(name):
            return price
    return 0


def mod_meta(jar):
    mod_id = None
    display = None
    try:
        with zipfile.ZipFile(jar) as zf:
            names = zf.namelist()
            if "META-INF/mods.toml" in names:
                text = zf.read("META-INF/mods.toml").decode("utf-8", "ignore")
                m = re.search(r'modId\s*=\s*"([^"]+)"', text)
                if m:
                    mod_id = m.group(1)
                m = re.search(r'displayName\s*=\s*"([^"]+)"', text)
                if m:
                    display = m.group(1)
            elif "fabric.mod.json" in names:
                import json

                data = json.loads(zf.read("fabric.mod.json").decode("utf-8", "ignore"))
                mod_id = data.get("id")
                display = data.get("name")
    except Exception:
        return None, None
    return mod_id, display


def item_ids(jar, mod_id):
    ids = []
    with zipfile.ZipFile(jar) as zf:
        prefix = "assets/%s/models/item/" % mod_id
        for name in zf.namelist():
            if name.startswith(prefix) and name.endswith(".json"):
                ids.append(name[len(prefix):-5])
    return ids


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mods", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--mc-jar", default=None)
    args = parser.parse_args()

    lines = []
    report = []
    skipped = []

    if args.mc_jar and os.path.isfile(args.mc_jar):
        ids = item_ids(args.mc_jar, "minecraft")
        priced = 0
        for item in sorted(ids):
            price = price_of("minecraft:" + item)
            if price:
                lines.append("minecraft:%s=%d" % (item, price))
                priced += 1
        report.append("minecraft: %d items, %d priced" % (len(ids), priced))

    jars = sorted(f for f in os.listdir(args.mods) if f.lower().endswith(".jar"))
    for jar_name in jars:
        path = os.path.join(args.mods, jar_name)
        mod_id, display = mod_meta(path)
        if not mod_id:
            skipped.append(jar_name + " (no mods.toml/fabric.mod.json)")
            continue
        try:
            ids = item_ids(path, mod_id)
        except Exception as ex:
            skipped.append("%s (%s)" % (jar_name, ex))
            continue
        if len(ids) < 5:
            skipped.append("%s [%s]: only %d items, treated as a library/utility mod" % (jar_name, mod_id, len(ids)))
            continue
        priced = 0
        block = ["", "// %s (%s) - %s" % (mod_id, display or "?", jar_name)]
        for item in sorted(ids):
            price = price_of("%s:%s" % (mod_id, item))
            if price:
                block.append("%s:%s=%d" % (mod_id, item, price))
                priced += 1
        if priced:
            lines.extend(block)
        report.append("%s [%s]: %d items, %d priced" % (jar_name, mod_id, len(ids), priced))

    with open(args.out, "w", encoding="utf-8") as fh:
        fh.write("// Generated by tools/gen_prices.py from the installed jars. Prices are a starting point.\n")
        fh.write("// Format: item_id=price   // lines starting with // are ignored\n")
        for line in lines:
            fh.write(line + "\n")

    print("\n".join(report))
    print("\nskipped:")
    print("\n".join("  " + s for s in skipped))
    print("\ntotal price lines: %d" % sum(1 for line in lines if line and not line.startswith("//")))


if __name__ == "__main__":
    main()
