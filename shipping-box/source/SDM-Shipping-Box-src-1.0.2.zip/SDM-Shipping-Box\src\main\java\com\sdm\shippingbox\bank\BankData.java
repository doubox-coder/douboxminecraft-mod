package com.sdm.shippingbox.bank;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Per-player coin balance of the shipping box bank.
 *
 * This is the seam where a real economy mod (SDM Shop) would plug in: keep the storage and the
 * command surface, replace {@link BankService#deposit(ServerPlayer, long)} with a call into that mod.
 */
public class BankData extends SavedData {

    public static final String FILE_ID = "sdmbox_bank";

    private final Map<UUID, Long> balances = new HashMap<>();

    public static BankData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(BankData::load, BankData::new, FILE_ID);
    }

    public static BankData load(CompoundTag tag) {
        BankData data = new BankData();
        ListTag list = tag.getList("Players", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            String id = entry.getString("Id");
            if (id.isEmpty()) {
                continue;
            }
            try {
                data.balances.put(UUID.fromString(id), entry.getLong("Balance"));
            } catch (IllegalArgumentException ignored) {
            }
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Map.Entry<UUID, Long> entry : this.balances.entrySet()) {
            CompoundTag line = new CompoundTag();
            line.putString("Id", entry.getKey().toString());
            line.putLong("Balance", entry.getValue());
            list.add(line);
        }
        tag.put("Players", list);
        return tag;
    }

    public long get(UUID player) {
        return this.balances.getOrDefault(player, 0L);
    }

    public void set(UUID player, long balance) {
        if (balance <= 0L) {
            this.balances.remove(player);
        } else {
            this.balances.put(player, balance);
        }
        this.setDirty();
    }

    public void add(UUID player, long amount) {
        this.set(player, this.get(player) + amount);
    }
}
