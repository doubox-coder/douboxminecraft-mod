# SDM 出货箱 / SDM Shipping Box

Minecraft **1.20.1 · Forge** 模组，作者 **DouBox**。
给 SDM Shop 加一个能把东西卖成钱的出货箱，卖东西赚到的钱可以存进银行、变成 SDM 商店认得的那种货币。

- modid = `sdmbox`
- 方块 = Shipping Box（中文名也显示 Shipping Box，按需求用英文）
- 版本 = 1.0.0

---

## 一、出货箱做了什么

**大箱子格式**：54 个输入格（6×9 全用满），没有出款格。
放进去的物品按价格表结算，钱直接打进出货箱主人的钱包 = SDM 商店那个货币，不再经过硬币。

- 每 20 秒（可在配置里改）结算一次，只结算有价格的物品
- 价格表没写的东西不会被结算，也不会被吞掉
- 主人不在线时钱先记账存在箱子里，主人一上线或一开箱立刻补发
- 箱子被破坏时，里面的东西按配置掉落（默认掉落），没收走的钱跟着箱子一起记着

## 二、每日出售报告

游戏内的每一天会单独统计：卖了多少件、收入多少、卖得最多的是哪三样。
时间跨天（睡觉跳过夜晚也算）之后，主人屏幕上会弹一行大字：

- 标题 = 「昨日出售 37 件」
- 副标题 = 「番茄 x12  牛肉 x5  …  |  共 268 币」

主人当时不在线，就等他一上线或者一开箱再弹。

## 三、硬币与银行

硬币（`sdmbox:coin`）仍然存在，但出货箱不再产出它，卖东西直接给钱。
手里有硬币时 **Shift + 右键** 出货箱，照旧存进银行。

- 装了 **SDM Economy**（`sdm_economy`）时，存货就是它注册的货币 `basic_money`，
  和 SDM 商店共用同一个余额
- 没装 SDM Economy 时，退回使用模组自带的每人一份余额，不会报错
- `/sdmbank balance` 看余额
- `/sdmbank withdraw <数量>` 把余额换回硬币（仅限自带余额；SDM 经济模式下钱归商店管，直接去商店花）

SDM 经济的方法是反射调用的，签名是从真实 jar 里读出来的：

```
net.sixik.sdm_economy.api.CurrencyHelper#addMoney(Player, String, long)
net.sixik.sdm_economy.api.CurrencyHelper#getMoney(Player, String, long)
```

默认货币 key 为 `basic_money`（`CurrencyRegister.init()` 里注册的那个），可在配置里改。

## 四、价格表

价格全部固定写在配置文件里，三条来源，后读的覆盖先读的，`item=` 优先于 `tag=`：

1. jar 内置 `data/sdmbox/prices/default_prices.txt`（原版基础价）
2. jar 内置 `data/sdmbox/prices/mod_prices.txt`（生成的价目表，**5693 条，每条一个独立单价**）
3. `config/sdmbox-common.toml` 里的 `[prices] entries`（你手动写的覆盖）

`mod_prices.txt` 不是凭记忆编的：脚本 `tools/gen_prices.py` 打开每个 jar，读
`assets/<modid>/models/item/*.json` 拿到**真实存在**的物品 ID，再按关键词定价。

本次生成用的是 Modrinth 官方 1.20.1 Forge jar（森罗物语 3 个 + 农夫乐事全家 10 个），
加上整合包原表里的其它 mod 与原版物品，合并去重后共 **5693 条**，每条一个独立单价。
覆盖到的重点系列：

- 森罗物语 = Kaleidoscope 系列：`kaleidoscope_cookery`（森罗物语：厨房）、
  `kaleidoscope_tavern`（森罗物语：酒馆）、`kaleidoscope_world_liquor`（森罗酒馆：世界名酒）
- 农夫乐事系列：`farmersdelight`、`farmersrespite`、`nethersdelight`、`ends_delight`、
  `oceansdelight`、`culturaldelights`、`pineapple_delight`、`spanishdelight`、
  `gobberdelight`、`ramadandelight`、`nydelight`、`alexsdelight`、`alexs_caves_delight`
- 另有 create、alexsmobs、alexscaves、supplementaries、sophisticatedbackpacks、toms_storage、
  drinkbeer、vinery、bakery、herbalbrews、farm_and_charm、letsdo 系列等

只装了 0–4 个物品的库/工具类模组（modernfix、curios、geckolib、architectury…）被跳过，避免乱定价。
没被写进价目表的物品，交给你在配置里补。

换整合包时重跑一次脚本就行：

```
python tools/gen_prices.py --mods "<整合包>/mods" ^
       --out src/main/resources/data/sdmbox/prices/mod_prices.txt ^
       --mc-jar <1.20.1 client.jar>
```

`--mc-jar` 是原版那 654 条 ID 的来源；不给也能跑，只是没有原版物品。

### 定价规则（脚本里）

现在的规则是**每个物品一个独立单价，全表没有一个价格被重复使用**。单价用两位小数，
同一批物品相加后向下取整发币。

价格分档，从低到高：

| 档位 | 判断 | 档内单价区间 |
|---|---|---|
| 建材 | log / planks / stairs / crate / leaves / 各类原版方块 | 1.00 - 21.43 |
| 材料 | leather / bone / string / dust / nugget / 盔甲杂物 | 21.73 - 39.90 |
| 生食 | raw_ / seed / crop / dough / 蛋 | 40.20 - 41.33 |
| 食材 | 其余食物、水果、蔬菜 | 41.63 - 44.82 |
| 工具 | knife / shears / pan / pot | 45.12 - 45.90 |
| 甜点 | cake / cookie / jam / honey / pie | 46.20 - 48.09 |
| 熟食 | cooked / baked / soup / stew / bread / 卷饼 | 48.39 - 51.98 |
| 饮品 | juice / tea / coffee / milk | 52.28 - 53.83 |
| 酒 | wine / beer / sake / whisky / 伏特加 / 白酒 | 54.13 - 63.13 |
| 金属 | iron / gold / copper / steel | 63.43 - 66.05 |
| 宝石 | diamond / emerald / netherite / amethyst | 66.35 - 66.82 |

酒单独占一档、压在饮品之上，档内跨度也拉到 0.03 一档，所以酒明显比别的喝的贵。

重新生成价格表（改完 `tools/reprice.py` 的档位或关键词后跑一次）：

```
python tools/reprice.py --bundled mod_prices.txt --mods "<整合包>/mods" ^
       --out mod_prices.txt --csv 价格表.csv
```

`--mods` 目录里放要解析的 jar，脚本读 `assets/<modid>/models/item` 拿真实物品 ID，
读 `lang/zh_cn.json` 拿中文名。

## 五、合成

一个出货箱：

```
木板 木板 木板
木板 铁锭 木板
木板 木板 木板      → 需要铁锭 1 + 木板 8
```

配方在 `data/sdmbox/recipes/shipping_box.json`，并带配方解锁进度。

## 六、配置项（`config/sdmbox-common.toml`）

| 键 | 默认 | 说明 |
|---|---|---|
| `settle_interval_seconds` | 20 | 结算间隔，1–3600 秒 |
| `sale_multiplier` | 1.0 | 售价倍率，0–100 |
| `restrict_input` | true | 只允许放有价格的物品 |
| `drop_contents_on_break` | true | 破坏时掉落内容 |
| `bank_enabled` | true | 允许 Shift + 右键存硬币（卖东西已经不产硬币，这只管手里捡到的） |
| `use_sdm_economy` | true | 存的钱交给 SDM Economy |
| `sdm_currency_key` | basic_money | SDM 经济里的货币 key |
| `[prices] entries` | 示例两条 | `farmersdelight:tomato=3`、`#forge:crops=2` |

## 七、怎么编译

需要 **JDK 17** 和 Gradle（8.x）。

```
gradlew build
```

产物在 `build/libs/sdmbox-1.0.0.jar`。
本机没有附带 gradle wrapper 的 jar 时，用已安装的 Gradle 也行：

```
gradle build
```

首次构建会联网拉 Forge / Minecraft 依赖，之后便走缓存。

## 八、贴图

`tools/make_assets.py` 用像素脚本从零画出来的，没经过任何 AI 图像模型：

- `logo.png` 64×64：深棕描边 + 木箱 + 金币徽章
- 方块四向贴图 16×16：木板纹理 + 铁箍 + 正面出货口箭头
- 硬币 16×16
- GUI 176×222：54 格大箱子，直接 9×6 排满，没有出款格

改颜色或尺寸直接改脚本重跑。

## 九、文件结构

```
src/main/java/com/sdm/shippingbox/
├── SDMShippingBox.java        主类
├── Config.java                配置
├── PriceRegistry.java         价格表（内置两份 + 配置覆盖）
├── registry/                  方块、物品、方块实体、菜单、创造标签
├── block/ShippingBoxBlock.java, ShippingBoxBlockEntity.java
├── menu/ShippingBoxMenu.java
├── client/ShippingBoxScreen.java, ClientSetup.java
└── bank/BankData.java, BankService.java, BankCommands.java, SdmShopBridge.java
```
