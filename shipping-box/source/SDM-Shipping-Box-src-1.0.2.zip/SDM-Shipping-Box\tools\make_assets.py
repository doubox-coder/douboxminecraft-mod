"""Draws every texture, the container GUI and the mod logo for SDM Shipping Box.

Everything here is hand-written pixel work: no image model is involved.
Run with:  python tools/make_assets.py
"""

import os
import random

from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "src", "main", "resources")
BLOCK_DIR = os.path.join(RES, "assets", "sdmbox", "textures", "block")
ITEM_DIR = os.path.join(RES, "assets", "sdmbox", "textures", "item")
GUI_DIR = os.path.join(RES, "assets", "sdmbox", "textures", "gui")

WOOD_DARK = (74, 50, 32)
WOOD_MID = (124, 84, 50)
WOOD_LIGHT = (146, 100, 58)
WOOD_HI = (172, 122, 73)
SEAM = (54, 34, 21)
HOLE = (26, 18, 12)
IRON = (134, 134, 134)
IRON_DARK = (86, 86, 86)
IRON_HI = (176, 176, 176)
GOLD = (223, 172, 66)
GOLD_HI = (250, 218, 130)
GOLD_DARK = (162, 113, 33)
GREEN = (104, 168, 78)
GREEN_DARK = (56, 102, 44)

PANEL = (198, 198, 198)
PANEL_HI = (255, 255, 255)
PANEL_LO = (85, 85, 85)
SLOT_FRAME = (139, 139, 139)
SLOT_INNER = (55, 55, 55)
SLOT_SHADE = (40, 40, 40)


def blank(size):
    return Image.new("RGBA", (size, size), (0, 0, 0, 0))


def px(img, x, y, color):
    if 0 <= x < img.width and 0 <= y < img.height:
        img.putpixel((x, y), color if len(color) == 4 else color + (255,))


def rect(img, x0, y0, x1, y1, color):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            px(img, x, y, color)


def plank_band(img, x0, x1, y0, y1, rng, base=WOOD_MID):
    rect(img, x0, y0, x1, y1, base)
    for x in range(x0, x1 + 1):
        px(img, x, y0, WOOD_LIGHT)
        px(img, x, y1, SEAM)
    dashes = max(2, (x1 - x0) // 4)
    for _ in range(dashes):
        gx = rng.randint(x0, x1 - 1)
        gy = rng.randint(y0 + 1, max(y0 + 1, y1 - 1))
        px(img, gx, gy, WOOD_HI if rng.random() < 0.45 else WOOD_LIGHT)


def strap(img, x0, x1, y0, y1):
    rect(img, x0, y0, x1, y1, IRON)
    for y in range(y0, y1 + 1):
        px(img, x0, y, IRON_HI)
        px(img, x1, y, IRON_DARK)


def base_crate(seed=20261113):
    img = blank(16)
    rect(img, 0, 0, 15, 15, WOOD_DARK)
    rng = random.Random(seed)
    plank_band(img, 1, 14, 1, 4, rng)
    plank_band(img, 1, 14, 6, 9, rng)
    plank_band(img, 1, 14, 11, 14, rng)
    rect(img, 1, 5, 14, 5, SEAM)
    rect(img, 1, 10, 14, 10, SEAM)
    # iron bands down the sides
    strap(img, 1, 2, 0, 15)
    strap(img, 13, 14, 0, 15)
    for y in (2, 7, 12):
        px(img, 1, y, IRON_DARK)
        px(img, 2, y, IRON_HI)
        px(img, 13, y, IRON_DARK)
        px(img, 14, y, IRON_HI)
    return img


def crate_side():
    return base_crate()


def crate_top():
    img = blank(16)
    rect(img, 0, 0, 15, 15, WOOD_DARK)
    rng = random.Random(77)
    plank_band(img, 1, 14, 1, 4, rng)
    plank_band(img, 1, 14, 6, 9, rng)
    plank_band(img, 1, 14, 11, 14, rng)
    rect(img, 1, 5, 14, 5, SEAM)
    rect(img, 1, 10, 14, 10, SEAM)
    strap(img, 0, 15, 1, 2)
    strap(img, 0, 15, 13, 14)
    # central latch
    rect(img, 6, 6, 9, 10, IRON_DARK)
    rect(img, 7, 7, 8, 9, IRON)
    px(img, 7, 7, IRON_HI)
    px(img, 8, 7, IRON_HI)
    return img


def crate_bottom():
    img = base_crate(4242)
    for y in range(16):
        for x in range(16):
            r, g, b, a = img.getpixel((x, y))
            if a == 0:
                continue
            px(img, x, y, (r * 5 // 8, g * 5 // 8, b * 5 // 8))
    return img


def crate_front():
    img = base_crate()
    # recessed hatch
    rect(img, 4, 4, 11, 11, SEAM)
    rect(img, 5, 5, 10, 10, HOLE)
    # green sell arrow
    for y in range(5, 8):
        px(img, 7, y, GREEN)
        px(img, 8, y, GREEN)
    for x in range(6, 10):
        px(img, x, 8, GREEN)
    px(img, 6, 8, GREEN_DARK)
    px(img, 9, 8, GREEN_DARK)
    px(img, 7, 9, GREEN_DARK)
    px(img, 8, 9, GREEN_DARK)
    px(img, 7, 5, GREEN_DARK)
    return img


def coin():
    img = blank(16)
    cx = 7.5
    cy = 7.5
    for y in range(16):
        for x in range(16):
            d = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
            if d > 7.1:
                continue
            if d > 6.2:
                color = GOLD_DARK
            elif d > 5.3:
                color = GOLD
            elif d > 4.7:
                color = GOLD_DARK
            else:
                color = GOLD
            px(img, x, y, color)
    for y in range(2, 6):
        for x in range(2, 6):
            if img.getpixel((x, y))[3] and (x + y) < 10:
                px(img, x, y, GOLD_HI)
    for x in (7, 8):
        px(img, x, 4, GREEN)
        px(img, x, 5, GREEN)
    for x in range(6, 10):
        px(img, x, 6, GREEN)
    px(img, 6, 6, GREEN_DARK)
    px(img, 9, 6, GREEN_DARK)
    px(img, 7, 7, GREEN_DARK)
    px(img, 8, 7, GREEN_DARK)
    px(img, 7, 4, GREEN_DARK)
    return img


def gui_background(width=176, height=222):
    img = Image.new("RGBA", (width, height), PANEL + (255,))
    for x in range(width):
        px(img, x, 0, PANEL_HI)
        px(img, x, height - 1, PANEL_LO)
    for y in range(height):
        px(img, 0, y, PANEL_HI)
        px(img, width - 1, y, PANEL_LO)
    for x in range(width):
        px(img, x, height - 2, PANEL_LO)
    for y in range(height):
        px(img, width - 2, y, PANEL_LO)

    def slot(x, y, frame=SLOT_FRAME):
        rect(img, x, y, x + 17, y + 17, frame)
        rect(img, x + 1, y + 1, x + 16, y + 16, SLOT_INNER)
        for i in range(x + 1, x + 17):
            px(img, i, y + 1, SLOT_SHADE)
        for i in range(y + 1, y + 17):
            px(img, x + 1, i, SLOT_SHADE)

    for row in range(6):
        for col in range(9):
            slot(7 + col * 18, 17 + row * 18)

    for row in range(3):
        for col in range(9):
            slot(7 + col * 18, 139 + row * 18)
    for col in range(9):
        slot(7 + col * 18, 197)

    return img


def coin_badge(size=32):
    art = coin().resize((size, size), Image.Resampling.NEAREST)
    ring = (46, 30, 16, 255)
    for y in range(size):
        for x in range(size):
            if art.getpixel((x, y))[3] == 0:
                continue
            neighbours = [(x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)]
            edge = False
            for nx, ny in neighbours:
                if not (0 <= nx < size and 0 <= ny < size) or art.getpixel((nx, ny))[3] == 0:
                    edge = True
                    break
            if edge:
                art.putpixel((x, y), ring)
    return art


def mod_logo():
    canvas = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    rect(canvas, 1, 1, 62, 62, (58, 40, 24))
    rect(canvas, 2, 2, 61, 61, (82, 57, 34))
    rect(canvas, 3, 3, 60, 60, (58, 40, 24))
    for cx, cy in ((1, 1), (62, 1), (1, 62), (62, 62)):
        px(canvas, cx, cy, (0, 0, 0, 0))
    crate = crate_front().resize((48, 48), Image.Resampling.NEAREST)
    canvas.paste(crate, (4, 4), crate)
    badge = coin_badge(32)
    canvas.paste(badge, (30, 30), badge)
    return canvas


def main():
    os.makedirs(BLOCK_DIR, exist_ok=True)
    os.makedirs(ITEM_DIR, exist_ok=True)
    os.makedirs(GUI_DIR, exist_ok=True)

    textures = {
        "shipping_box_side.png": crate_side(),
        "shipping_box_front.png": crate_front(),
        "shipping_box_top.png": crate_top(),
        "shipping_box_bottom.png": crate_bottom(),
    }
    for name, image in textures.items():
        image.save(os.path.join(BLOCK_DIR, name))

    coin().save(os.path.join(ITEM_DIR, "coin.png"))
    gui = gui_background()
    gui.save(os.path.join(GUI_DIR, "shipping_box.png"))

    logo = mod_logo()
    logo.save(os.path.join(RES, "logo.png"))

    for path in list(textures) + ["coin.png", "shipping_box.png", "logo.png"]:
        print("written", path)
    print("gui size", gui.size)


if __name__ == "__main__":
    main()
