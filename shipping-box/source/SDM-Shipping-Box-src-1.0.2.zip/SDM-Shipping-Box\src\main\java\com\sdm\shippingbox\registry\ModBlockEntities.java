package com.sdm.shippingbox.registry;

import com.sdm.shippingbox.SDMShippingBox;
import com.sdm.shippingbox.block.ShippingBoxBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlockEntities {

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, SDMShippingBox.MOD_ID);

    public static final RegistryObject<BlockEntityType<ShippingBoxBlockEntity>> SHIPPING_BOX =
            BLOCK_ENTITIES.register("shipping_box", () -> BlockEntityType.Builder
                    .of(ShippingBoxBlockEntity::new, ModBlocks.SHIPPING_BOX.get())
                    .build(null));

    private ModBlockEntities() {
    }
}
