package com.sdm.shippingbox.bank;

import com.sdm.shippingbox.SDMShippingBox;
import java.lang.reflect.Method;
import net.minecraft.world.entity.player.Player;

/**
 * Reflection bridge into SDM Economy (mod id sdm_economy, package net.sixik.sdm_economy).
 *
 * Signatures were read straight out of the shipped jar:
 *   net.sixik.sdm_economy.api.CurrencyHelper#addMoney(Player, String, long)
 *   net.sixik.sdm_economy.api.CurrencyHelper#getMoney(Player, String, long)
 * and the default currency registered by CurrencyRegister.init() is "basic_money".
 *
 * Reflection is used on purpose: the mod loads without SDM Economy installed and simply falls back
 * to the built-in balance instead of crashing.
 */
public final class SdmShopBridge {

    private static final String CURRENCY_CLASS = "net.sixik.sdm_economy.api.CurrencyHelper";

    private static boolean resolved;
    private static Method addMoney;
    private static Method getMoney;

    private SdmShopBridge() {
    }

    private static void resolve() {
        if (resolved) {
            return;
        }
        resolved = true;
        try {
            Class<?> helper = Class.forName(CURRENCY_CLASS);
            addMoney = helper.getMethod("addMoney", Player.class, String.class, long.class);
            getMoney = helper.getMethod("getMoney", Player.class, String.class, long.class);
            SDMShippingBox.LOGGER.info("SDM Economy found, banking will use its currency.");
        } catch (Throwable ignored) {
            addMoney = null;
            getMoney = null;
            SDMShippingBox.LOGGER.info("SDM Economy not installed, banking uses the built-in balance.");
        }
    }

    public static boolean available() {
        resolve();
        return addMoney != null;
    }

    public static boolean add(Player player, String currency, long amount) {
        resolve();
        if (addMoney == null || amount == 0L) {
            return false;
        }
        try {
            addMoney.invoke(null, player, currency, amount);
            return true;
        } catch (Throwable ex) {
            SDMShippingBox.LOGGER.error("SDM Economy addMoney failed: {}", ex.toString());
            return false;
        }
    }

    public static long balance(Player player, String currency) {
        resolve();
        if (getMoney == null) {
            return -1L;
        }
        try {
            Object value = getMoney.invoke(null, player, currency);
            return value instanceof Long l ? l : -1L;
        } catch (Throwable ex) {
            SDMShippingBox.LOGGER.error("SDM Economy getMoney failed: {}", ex.toString());
            return -1L;
        }
    }
}
