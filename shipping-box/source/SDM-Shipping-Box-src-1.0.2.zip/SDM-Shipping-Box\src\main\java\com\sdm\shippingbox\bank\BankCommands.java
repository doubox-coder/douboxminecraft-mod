package com.sdm.shippingbox.bank;

import com.sdm.shippingbox.SDMShippingBox;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SDMShippingBox.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class BankCommands {

    private BankCommands() {
    }

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal("sdmbank")
                .then(Commands.literal("balance")
                        .executes(ctx -> {
                            ServerPlayer player = ctx.getSource().getPlayerOrException();
                            long balance = BankService.balance(player);
                            ctx.getSource().sendSuccess(
                                    () -> Component.translatable("message.sdmbox.balance", balance), false);
                            return 1;
                        }))
                .then(Commands.literal("withdraw")
                        .then(Commands.argument("amount", IntegerArgumentType.integer(1, 65536))
                                .executes(ctx -> {
                                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                                    int amount = IntegerArgumentType.getInteger(ctx, "amount");
                                    if (!BankService.withdraw(player, amount)) {
                                        ctx.getSource().sendFailure(
                                                Component.translatable("message.sdmbox.not_enough"));
                                        return 0;
                                    }
                                    return 1;
                                }))
                        .executes(ctx -> {
                            ServerPlayer player = ctx.getSource().getPlayerOrException();
                            long balance = BankService.balance(player);
                            if (balance <= 0L || !BankService.withdraw(player, balance)) {
                                ctx.getSource().sendFailure(
                                        Component.translatable("message.sdmbox.not_enough"));
                                return 0;
                            }
                            return 1;
                        })));
    }
}
