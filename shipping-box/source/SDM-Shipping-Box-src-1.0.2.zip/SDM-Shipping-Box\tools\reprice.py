"""Rebuild the bundled price list so that every item has its own price.

Rules
- one item id -> one price, and no two items share the same price
- every price uses two decimals, so 5000+ ids still fit into a small range
- tiers are ordered low to high: blocks < materials < raw < ingredients < tools
  < sweets < cooked < drinks < liquor < metals < gems
- inside a tier the slots are handed out by a stable hash, so neighbouring
  ids do not get neighbouring prices (the table does not look mechanical)

Usage:
    python tools/reprice.py --bundled <mod_prices.txt> --mods <dir with jars> \
        --out <new mod_prices.txt> --csv <sheet.csv>
"""

import argparse
import csv
import hashlib
import json
import os
import re
import zipfile

TIERS = [
    ("建材", re.compile(r"(log|wood|planks|slab|stairs|fence|wall|door|trapdoor|carpet|"
                       r"leaves|sapling|crate|pane|sign|soil|farmland|stem|bricks|"
                       r"_block$|_ore$|glass)", re.I)),
    ("材料", re.compile(r"(leather|wool|string|bone|feather|flint|clay|dust|nugget|"
                       r"scrap|fragment|shell|membrane|pearl|powder|stick|paper|"
                       r"helmet|chestplate|leggings|boots)", re.I)),
    ("生食", re.compile(r"(^raw_|_seed$|_seeds$|_crop$|dough|batter|flesh|fillet|"
                       r"uncooked|_egg$)", re.I)),
    ("工具", re.compile(r"(knife|shears|sword|pickaxe|axe|shovel|hoe|hammer|pan|pot$|"
                       r"skillet|wok|mortar|pestle)", re.I)),
    ("甜点", re.compile(r"(cake|cookie|candy|chocolate|donut|muffin|pudding|dessert|"
                       r"jam|syrup|honey|pie|ice_cream|sorbet|jelly)", re.I)),
    ("熟食", re.compile(r"(cooked|baked|roasted|grilled|fried|smoked|soup|stew|curry|"
                       r"meal|dish|sandwich|burger|pizza|taco|noodle|pasta|dumpling|"
                       r"bun|sushi|salad|bread|toast|pancake|waffle|jerky|sausage|"
                       r"bacon|ham|broth|porridge|chowder|gumbo|rice|burrito|wrap|"
                       r"roll|bowl|feast|platter|slice|risotto|fries|chips|cake)", re.I)),
    ("饮品", re.compile(r"(juice|tea|coffee|drink|soda|smoothie|milkshake|"
                       r"milk|bottle|water|cocktail|sake|beer|wine|cider|liquor|"
                       r"whisky|whiskey|rum|vodka|brandy|champagne|mead|ale|gin|"
                       r"tequila|moonshine|spirit|baijiu|huangjiu)", re.I)),
    ("金属", re.compile(r"(iron|steel|gold|copper|bronze|brass|silver|tin|lead|"
                       r"nickel|zinc|tungsten|platinum|aluminium|aluminum)", re.I)),
    ("宝石", re.compile(r"(diamond|emerald|netherite|ancient_debris|amethyst|lapis|"
                       r"quartz|redstone|ruby|sapphire|topaz|opal|crystal)", re.I)),
]

# 酒单独一层，压在饮品之上，保证「酒比别的都贵」
WINE = re.compile(r"(wine|sake|beer|cider|liquor|whisky|whiskey|rum|vodka|brandy|"
                  r"champagne|mead|ale|gin|tequila|moonshine|spirit|baijiu|huangjiu|"
                  r"cocktail|cognac|schnapps|soju)", re.I)

FOOD_ANY = re.compile(r"(cooked|baked|roasted|grilled|fried|smoked|soup|stew|pie|cake|"
                      r"cookie|bread|rice|noodle|pasta|dumpling|bun|sushi|salad|sandwich|"
                      r"burger|cheese|jerky|sausage|bacon|ham|meat|fish|fillet|egg|juice|"
                      r"tea|coffee|drink|fruit|berry|vegetable|mushroom|tomato|onion|"
                      r"cabbage|carrot|potato|corn|wheat|seed|crop|herb|spice|salt|sugar|"
                      r"flour|dough|food|meal|dish|pudding|dessert|snack|candy|sweet|"
                      r"avocado|burrito|wrap|roll|bowl|feast|platter|slice|tofu|soy|"
                      r"bean|nut|peanut|almond|coconut|banana|apple|orange|lemon|grape|"
                      r"melon|peach|pear|plum|cherry|pineapple|mango|kiwi)", re.I)

ORDER = ["建材", "材料", "生食", "食材", "工具", "甜点", "熟食", "饮品", "酒", "金属", "宝石"]


def tier_of(item_id):
    name = item_id.split(":")[-1]
    if WINE.search(name):
        return "酒"
    for tier, pattern in TIERS:
        if pattern.search(name):
            return tier
    if FOOD_ANY.search(name):
        return "食材"
    return "材料"


def slot_hash(item_id):
    return hashlib.sha1(item_id.encode("utf-8")).hexdigest()


def jar_ids(jar):
    mod_id = None
    with zipfile.ZipFile(jar) as zf:
        names = zf.namelist()
        if "META-INF/mods.toml" in names:
            text = zf.read("META-INF/mods.toml").decode("utf-8", "ignore")
            m = re.search(r'modId\s*=\s*"([^"]+)"', text)
            mod_id = m.group(1) if m else None
        if not mod_id:
            return None, []
        prefix = "assets/%s/models/item/" % mod_id
        ids = [n[len(prefix):-5] for n in names if n.startswith(prefix) and n.endswith(".json")]
        return mod_id, ids


def zh_names(jar, mod_id):
    names = {}
    with zipfile.ZipFile(jar) as zf:
        path = "assets/%s/lang/zh_cn.json" % mod_id
        if path in zf.namelist():
            try:
                data = json.loads(zf.read(path).decode("utf-8-sig", "ignore"))
            except Exception:
                return names
            for key, value in data.items():
                parts = key.split(".")
                if len(parts) < 3 or parts[0] not in ("item", "block"):
                    continue
                if parts[1] != mod_id:
                    continue
                item = parts[2]
                if isinstance(value, str) and value.strip():
                    names.setdefault(item, value.strip())
    return names


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bundled", required=True)
    ap.add_argument("--mods", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--csv", required=True)
    args = ap.parse_args()

    ids = []
    seen = set()
    with open(args.bundled, encoding="utf-8") as fh:
        for line in fh:
            text = line.strip()
            if not text or text.startswith("//"):
                continue
            key = text.split("=")[0].strip()
            if key.startswith("#"):
                continue
            if key and key not in seen:
                seen.add(key)
                ids.append(key)

    names = {}
    sources = {}
    for jar_name in sorted(os.listdir(args.mods)):
        if not jar_name.lower().endswith(".jar"):
            continue
        path = os.path.join(args.mods, jar_name)
        try:
            mod_id, jar_items = jar_ids(path)
        except Exception:
            continue
        if not mod_id:
            continue
        for item in jar_items:
            full = "%s:%s" % (mod_id, item)
            sources[full] = (jar_name, mod_id)
            if full not in seen:
                seen.add(full)
                ids.append(full)
        for item, value in zh_names(path, mod_id).items():
            full = "%s:%s" % (mod_id, item)
            if full in seen:
                names.setdefault(full, value)

    groups = {}
    for item in ids:
        groups.setdefault(tier_of(item), []).append(item)

    # 每个层给一段连续的价格槽位，层与层之间留 0.30 的空档；
    # 层内按 hash 排序后依次取槽，保证同层不同价、跨层也不撞。
    # 酒这一层用 0.03 一档，跨度更宽，让酒明显压在饮品之上。
    step_of = {"酒": 3}
    price = {}
    cursor = 100  # 单位是 0.01 币，即从 1.00 开始
    band_report = []
    for tier in ORDER:
        bucket = groups.get(tier, [])
        if not bucket:
            continue
        bucket.sort(key=slot_hash)
        step = step_of.get(tier, 1)
        start = cursor
        for index, item in enumerate(bucket):
            price[item] = (start + index * step) / 100.0
        span = (len(bucket) - 1) * step
        cursor = start + span + 30
        band_report.append((tier, len(bucket), start / 100.0, (start + span) / 100.0))

    leftovers = [t for t in groups if t not in ORDER]
    for tier in leftovers:
        bucket = sorted(groups[tier], key=slot_hash)
        start = cursor
        for index, item in enumerate(bucket):
            price[item] = (start + index) / 100.0
        cursor = start + len(bucket) + 30

    def fmt(value):
        return ("%.2f" % value).rstrip("0").rstrip(".")

    lines = [
        "// SDM Shipping Box - bundled price list, one unique price per item.",
        "// Format: item_id=price      // lines starting with // are ignored",
        "// Prices use two decimals on purpose: every item in this file has its own value,",
        "// and no two items share one. Rebuild with tools/reprice.py.",
        "",
    ]
    last_mod = None
    for item in sorted(ids):
        mod = item.split(":")[0]
        if mod != last_mod:
            lines.append("// ---- %s ----" % mod)
            last_mod = mod
        lines.append("%s=%s" % (item, fmt(price[item])))

    with open(args.out, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")

    target_mods = {
        "kaleidoscope_cookery", "kaleidoscope_tavern", "kaleidoscope_world_liquor",
        "farmersdelight", "culturaldelights", "ends_delight", "nethersdelight",
        "oceansdelight", "pineapple_delight", "ramadandelight", "spanishdelight",
        "nydelight", "farmersrespite",
    }
    rows = []
    for item in sorted(ids):
        mod = item.split(":")[0]
        if mod not in target_mods:
            continue
        rows.append([item, names.get(item, ""), fmt(price[item]), tier_of(item), mod])
    with open(args.csv, "w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["物品ID", "中文名", "单价", "分类", "来源mod"])
        writer.writerows(rows)

    values = list(price.values())
    print("total ids      :", len(ids))
    print("unique prices  :", len(set(round(v, 2) for v in values)))
    print("price range    : %.2f - %.2f" % (min(values), max(values)))
    print("sheet rows     :", len(rows), "(named:", sum(1 for r in rows if r[1]), ")")
    for tier, count, lo, hi in band_report:
        print("  %-4s %5d  %.2f - %.2f" % (tier, count, lo, hi))


if __name__ == "__main__":
    main()
