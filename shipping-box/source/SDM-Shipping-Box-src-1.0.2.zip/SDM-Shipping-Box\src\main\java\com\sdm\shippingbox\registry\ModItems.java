package com.sdm.shippingbox.registry;

import com.sdm.shippingbox.SDMShippingBox;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, SDMShippingBox.MOD_ID);

    public static final RegistryObject<Item> SHIPPING_BOX = ITEMS.register("shipping_box",
            () -> new BlockItem(ModBlocks.SHIPPING_BOX.get(), new Item.Properties()));

    public static final RegistryObject<Item> COIN = ITEMS.register("coin",
            () -> new Item(new Item.Properties().stacksTo(64)));

    private ModItems() {
    }
}
