package com.sdm.shippingbox;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

public final class PriceRegistry {

    private static final String[] BUNDLED_PRICES = {
            "/data/sdmbox/prices/default_prices.txt",
            "/data/sdmbox/prices/mod_prices.txt"
    };

    private static final Map<Item, Double> ITEM_PRICES = new HashMap<>();
    private static final List<TagPrice> TAG_PRICES = new ArrayList<>();

    private PriceRegistry() {
    }

    public static void bake() {
        ITEM_PRICES.clear();
        TAG_PRICES.clear();

        int bundled = loadBundled();
        int fromConfig = loadConfig();
        SDMShippingBox.LOGGER.info("Prices ready: {} bundled entries, {} config entries, {} item prices, {} tag prices.",
                bundled, fromConfig, ITEM_PRICES.size(), TAG_PRICES.size());
    }

    private static int loadBundled() {
        int applied = 0;
        for (String resource : BUNDLED_PRICES) {
            applied += loadBundledFile(resource);
        }
        return applied;
    }

    private static int loadBundledFile(String resource) {
        try (InputStream stream = PriceRegistry.class.getResourceAsStream(resource)) {
            if (stream == null) {
                SDMShippingBox.LOGGER.warn("Bundled price list {} is missing from the jar.", resource);
                return 0;
            }
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
            int applied = 0;
            String line;
            while ((line = reader.readLine()) != null) {
                if (apply(line)) {
                    applied++;
                }
            }
            return applied;
        } catch (Exception ex) {
            SDMShippingBox.LOGGER.warn("Could not read the bundled price list {}: {}", resource, ex.toString());
            return 0;
        }
    }

    private static int loadConfig() {
        List<? extends String> entries;
        try {
            entries = Config.PRICES.get();
        } catch (IllegalStateException ex) {
            SDMShippingBox.LOGGER.warn("Price list requested before the config was loaded.");
            return 0;
        }
        int applied = 0;
        for (String entry : entries) {
            if (entry != null && apply(entry)) {
                applied++;
            }
        }
        return applied;
    }

    private static boolean apply(String raw) {
        if (raw == null) {
            return false;
        }
        String entry = raw.trim();
        if (entry.isEmpty() || entry.startsWith("//")) {
            return false;
        }
        int split = entry.lastIndexOf('=');
        if (split <= 0 || split == entry.length() - 1) {
            SDMShippingBox.LOGGER.warn("Skipped malformed price entry: {}", entry);
            return false;
        }
        String key = entry.substring(0, split).trim();
        double price;
        try {
            price = Math.round(Double.parseDouble(entry.substring(split + 1).trim()) * 100.0D) / 100.0D;
        } catch (NumberFormatException ex) {
            SDMShippingBox.LOGGER.warn("Skipped price entry with a non-numeric price: {}", entry);
            return false;
        }
        if (!Double.isFinite(price) || price <= 0.0D) {
            return false;
        }

        if (key.startsWith("#")) {
            ResourceLocation tagId = ResourceLocation.tryParse(key.substring(1).toLowerCase(Locale.ROOT));
            if (tagId == null) {
                return false;
            }
            TAG_PRICES.add(new TagPrice(TagKey.create(Registries.ITEM, tagId), price));
            return true;
        }

        ResourceLocation itemId = ResourceLocation.tryParse(key.toLowerCase(Locale.ROOT));
        if (itemId == null) {
            return false;
        }
        Item item = ForgeRegistries.ITEMS.getValue(itemId);
        if (item == null) {
            return false;
        }
        ITEM_PRICES.put(item, price);
        return true;
    }

    public static double priceOf(ItemStack stack) {
        if (stack.isEmpty()) {
            return 0.0D;
        }
        Double direct = ITEM_PRICES.get(stack.getItem());
        if (direct != null) {
            return direct;
        }
        for (TagPrice tagPrice : TAG_PRICES) {
            if (stack.is(tagPrice.tag())) {
                return tagPrice.price();
            }
        }
        return 0.0D;
    }

    public static boolean hasPrice(ItemStack stack) {
        return priceOf(stack) > 0.0D;
    }

    private record TagPrice(TagKey<Item> tag, double price) {
    }
}
