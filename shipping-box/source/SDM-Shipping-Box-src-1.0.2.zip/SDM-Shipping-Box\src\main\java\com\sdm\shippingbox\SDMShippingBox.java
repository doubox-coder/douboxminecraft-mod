package com.sdm.shippingbox;

import com.sdm.shippingbox.registry.ModBlockEntities;
import com.sdm.shippingbox.registry.ModBlocks;
import com.sdm.shippingbox.registry.ModItems;
import com.sdm.shippingbox.registry.ModMenus;
import com.sdm.shippingbox.registry.ModTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod(SDMShippingBox.MOD_ID)
public class SDMShippingBox {

    public static final String MOD_ID = "sdmbox";
    public static final Logger LOGGER = LoggerFactory.getLogger("SDM Shipping Box");

    public SDMShippingBox() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModMenus.MENUS.register(modBus);
        ModTabs.TABS.register(modBus);

        modBus.addListener(this::commonSetup);
        modBus.addListener(Config::onLoad);
        modBus.addListener(Config::onReload);

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC, "sdmbox-common.toml");
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(PriceRegistry::bake);
    }
}
