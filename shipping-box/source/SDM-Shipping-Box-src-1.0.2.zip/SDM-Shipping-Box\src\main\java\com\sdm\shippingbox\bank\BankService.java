package com.sdm.shippingbox.bank;

import com.sdm.shippingbox.Config;
import com.sdm.shippingbox.registry.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public final class BankService {

    private BankService() {
    }

    private static boolean useSdm() {
        return Config.useSdmEconomy() && SdmShopBridge.available();
    }

    public static long balance(ServerPlayer player) {
        if (useSdm()) {
            long value = SdmShopBridge.balance(player, Config.sdmCurrencyKey());
            if (value >= 0L) {
                return value;
            }
        }
        return BankData.get(player.serverLevel()).get(player.getUUID());
    }

    /**
     * Pays money straight into the player's purse, without any coin item in between.
     * SDM Economy owns the money when it is installed; otherwise the built-in balance is used.
     *
     * @return the balance after the payment, or -1 when nothing could be paid
     */
    public static long credit(ServerPlayer player, long coins) {
        if (coins <= 0L) {
            return -1L;
        }
        if (useSdm() && SdmShopBridge.add(player, Config.sdmCurrencyKey(), coins)) {
            return SdmShopBridge.balance(player, Config.sdmCurrencyKey());
        }
        BankData data = BankData.get(player.serverLevel());
        data.add(player.getUUID(), coins);
        return data.get(player.getUUID());
    }

    /**
     * Puts coins into the bank. With SDM Economy installed the coins become that mod's currency,
     * otherwise they go into the mod's own per-player balance.
     *
     * @return the new balance, or -1 when banking is switched off
     */
    public static long deposit(ServerPlayer player, long coins) {
        if (!Config.bankEnabled() || coins <= 0L) {
            return -1L;
        }
        if (useSdm() && SdmShopBridge.add(player, Config.sdmCurrencyKey(), coins)) {
            long now = SdmShopBridge.balance(player, Config.sdmCurrencyKey());
            player.displayClientMessage(Component.translatable("message.sdmbox.deposited_sdm", coins, now), true);
            return now;
        }
        BankData data = BankData.get(player.serverLevel());
        data.add(player.getUUID(), coins);
        long now = data.get(player.getUUID());
        player.displayClientMessage(Component.translatable("message.sdmbox.deposited", coins, now), true);
        return now;
    }

    /**
     * Only the built-in balance can be turned back into coins. When SDM Economy owns the money,
     * that belongs to the shop and this method refuses instead of guessing at a refund.
     */
    public static boolean withdraw(ServerPlayer player, long coins) {
        if (!Config.bankEnabled() || coins <= 0L) {
            return false;
        }
        if (useSdm()) {
            player.displayClientMessage(Component.translatable("message.sdmbox.withdraw_sdm"), true);
            return false;
        }
        BankData data = BankData.get(player.serverLevel());
        long now = data.get(player.getUUID());
        if (now < coins) {
            return false;
        }
        int toGive = (int) Math.min(coins, 36L * 64L);
        data.set(player.getUUID(), now - toGive);

        int left = toGive;
        while (left > 0) {
            int amount = Math.min(64, left);
            ItemStack stack = new ItemStack(ModItems.COIN.get(), amount);
            if (!player.getInventory().add(stack)) {
                player.drop(stack, false);
            }
            left -= amount;
        }
        player.displayClientMessage(Component.translatable("message.sdmbox.withdrew", toGive, now - toGive), true);
        return true;
    }
}
